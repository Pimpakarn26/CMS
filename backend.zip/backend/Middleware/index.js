const verifySignUp = require("./verifySignUp");
const authJwt = require("./authJwt");

module.exports = {
    verifySignUp, // โมดูลที่ใช้สำหรับการตรวจสอบและยืนยันการลงทะเบียน
    authJwt,
}