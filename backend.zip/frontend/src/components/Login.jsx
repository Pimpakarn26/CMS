// import React from 'react';

// const Login = () => {
//   const handleLogin = (e) => {
//     e.preventDefault();
//     // ทำการประมวลผลการ login ที่นี่
//   };

//   return (
//     <div className="container mx-auto p-4">
//       <h2 className="text-3xl font-bold text-center mb-4">Login</h2>
//       <form onSubmit={handleLogin} className="max-w-md mx-auto">
//         <div className="mb-4">
//           <label className="label">
//             <span className="label-text">Email</span>
//           </label>
//           <input type="email" className="input input-bordered w-full" required />
//         </div>
//         <div className="mb-4">
//           <label className="label">
//             <span className="label-text">Password</span>
//           </label>
//           <input type="password" className="input input-bordered w-full" required />
//         </div>
//         <button type="submit" className="btn btn-primary w-full">Login</button>
//       </form>
//     </div>
//   );
// };

// export default Login;