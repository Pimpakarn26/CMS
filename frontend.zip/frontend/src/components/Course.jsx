import React, { useEffect, useState } from "react";
import Card from "./Card"; // Make sure this path is correct

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/courses'); // Replace with your API endpoint
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setCourses(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  if (loading) {
    return <div>Loading...</div>; // You can style this as needed
  }

  if (error) {
    return <div>Error: {error}</div>; // Handle errors here
  }

  return (
    <div className="flex flex-wrap justify-center gap-4">
      {courses.map((course) => (
        <Card
          key={course.code} // Assuming 'code' is unique for courses
          name={course.name}
          type={course.type}
          code={course.code}
          creditHours={course.creditHours}
          gradeLevel={course.gradeLevel}
          classroom={course.classroom}
        />
      ))}
    </div>
  );
};

// Ensure that the 'courses' prop is passed correctly when using this component
export default Courses;