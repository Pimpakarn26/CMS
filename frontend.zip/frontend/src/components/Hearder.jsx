import React from "react";

const Header = () => {
    return (
        <div>
            <h2 className="font-bold text-4xl text-center mt-5">Courses Management</h2>
        </div>
    );
};
export default Header;